
Readme :
Il suffit de compiler en mode release.
Puis une fenêtre 3D s'affiche : Shift + click pour voir différentes orientations.
Cliquer n'importe tout sur la fenêtre pour quitter.