
Readme :
Il suffit de compiler en mode release.
Puis une fenêtre 3D s'affiche : Shift + click pour voir différentes orientations.
Cliquer n'importe tout sur la fenêtre pour quitter.
Remarque : La fenêtre 3D fait apparaitre une espèce de colonne (telle une stalagmite) sur la gauche de l'image. 
C'est tout à fait normal. Cela vient du fait que la seconde image est une translation vers la droite, on perd donc l'information sur la gauche de l'image de gauche.